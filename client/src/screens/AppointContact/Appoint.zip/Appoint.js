import React, { useState, useEffect } from 'react';
import { View, Text, Image, TouchableOpacity, Keyboard, TextInput, ScrollView } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useNavigation } from '@react-navigation/native';
import { styles } from '../../styles/VetStyle/Vet';
import firestore from '@react-native-firebase/firestore';
import auth from '@react-native-firebase/auth';
// import checkmarkIcon from '../../assets/checkmark.png'
const AppointContact = () => {
  const [showContactButton, setShowContactButton] = useState(false);
  const [appointmentDate, setAppointmentDate] = useState(new Date());
  const [appointmentReason, setAppointmentReason] = useState('');
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showSubmitButton, setShowSubmitButton] = useState(false);
  const [dateSelected, setDateSelected] = useState(false); // State to track if a date has been selected
  const navigation = useNavigation();
  const [user, setUser] = useState(null);
  const [refresh, setRefresh] = useState(false);
  const doctor = {
    name: 'Dr. John Doe',
    specialty: 'Cardiologist',
    location: 'New York',
    image: 'https://placeimg.com/100/100/people',
    id: 1,
  };

  const db = firestore();

  useEffect(() => {
    const subscriber = auth().onAuthStateChanged((user) => {
      setUser(user);
    });

    return () => subscriber();
  }, []);

  const sendAppointment = () => {
    if (user && user.uid) {
      db.collection('Appointments').doc(doctor.id.toString()).collection(user.uid).add({
        userId: user.uid,
        doctorId: doctor.id,
        state: false,
        date: appointmentDate.toLocaleDateString(),
        reason: appointmentReason,
        timestamp: firestore.FieldValue.serverTimestamp(),
      })
        .then(() => {
          setRefresh(true);
          setShowSubmitButton(false);
          setShowContactButton(true);
          Keyboard.dismiss();
        })
        .catch(error => {
          console.error('Error adding appointment: ', error);
        });
    }
  };

  const handleAppointment = () => {
    setShowDatePicker(true);
    setShowSubmitButton(true);
  };

  const handleDateChange = (selectedDate) => {
    const currentDate = selectedDate || appointmentDate;
    setShowDatePicker(false);
    setAppointmentDate(currentDate);
    setDateSelected(true);
  };

  const handleContact = () => {
    navigation.navigate('ChatScreen', { doctor });
    console.log('Contact the doctor');
  };

  return (
    <ScrollView>
      <View style={styles.container}>
        <Image source={{ uri: doctor.image }} style={styles.photo} />

        <View style={styles.descriptionContainer}>
          <Text style={styles.name}>{doctor.name}</Text>
          <Text style={styles.specialization}>{doctor.specialty}</Text>
          <Text style={styles.description}>{doctor.description}</Text>
        </View>

        <TextInput
          style={styles.input}
          placeholder="Enter reason for appointment"
          value={appointmentReason}
          onChangeText={setAppointmentReason}
        />

        <TouchableOpacity style={styles.appointmentButton} onPress={handleAppointment}>
          <Text style={styles.buttonText}>Pick a Date</Text>
        </TouchableOpacity>

        {showDatePicker && (
          <DateTimePicker
            value={appointmentDate}
            mode="date"
            minimumDate={new Date()}
            maximumDate={new Date(2024, 12, 31)}
            onChange={handleDateChange}
          />
        )}


        {dateSelected && (
         <View style={styles.checkmarkIcon}>
         <Text style={styles.checkmarkText}>✓</Text>
       </View>
        )}

        {showSubmitButton && (
          <TouchableOpacity style={styles.contactButton} onPress={sendAppointment}>
            <Text style={styles.buttonText}>Submit</Text>
          </TouchableOpacity>
        )}

        {showContactButton && (
          <TouchableOpacity style={styles.contactButton} onPress={handleContact}>
            <Text style={styles.buttonText}>Contact Doctor</Text>
          </TouchableOpacity>
        )}
      </View>
    </ScrollView>
  );
};

export default AppointContact;
